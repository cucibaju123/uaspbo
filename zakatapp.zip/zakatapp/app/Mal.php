<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mal extends Model
{
    protected $fillable = ['id','nama_pengirim', 'nama_penerima', 'nominal_zakat', 'tanggal_terima'];
}
