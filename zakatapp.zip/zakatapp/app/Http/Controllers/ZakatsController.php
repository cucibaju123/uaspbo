<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use \App\Mal;

class ZakatsController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth', ['except' => 'index']);
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        if($request->has('cari')){
            $data_zakat = Mal::where('nama_pengirim', 'LIKE', '%'.$request->cari.'%')->get();
        }if($request->has('cari')){
            $data_zakat = Mal::where('nama_penerima', 'LIKE', '%'.$request->cari.'%')->get();
        }if($request->has('cari')){
            $data_zakat = Mal::where('id', 'LIKE', '%'.$request->cari.'%')->get();
        }else{
            $data_zakat = Mal:: all();
        }
        return view('zakat.index', ['data_zakat' => $data_zakat]);
    }

    public function add(){
        return view('zakat.add');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        //Data Validation
        $this->validate($request,[
            //Last time i stuck because i named the supposedly named 'id' column with 'nip'
            'nama_pengirim' => 'required',
            'nama_penerima' => 'required',
            'nominal_zakat' => 'required',
            'tanggal_terima' => 'required|date',
        ]);
        //Create Data
        $zakat = Mal::create($request->all());
        return redirect('/zakat')->with('success', 'Data berhasil ditambahkan');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $zakat = Mal::find($id);
        return view('zakat/edit', ['zakat' => $zakat]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //Data Validation
        $this->validate($request,[
            //Last time i stuck because i named the supposedly named 'id' column with 'nip'
            'nama_pengirim' => 'required',
            'nama_penerima' => 'required',
            'nominal_zakat' => 'required',
            'tanggal_terima' => 'required|date',
        ]);
        //Update Data
        $zakat = Mal::find($id);
        $zakat->update($request->all());
        return redirect('/zakat')->with('success', 'Data berhasil diupdate');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $zakat = Mal::find($id);
        $zakat->delete($zakat);
        return redirect('/zakat')->with('success', 'Data berhasil dihapus');
    }
}
