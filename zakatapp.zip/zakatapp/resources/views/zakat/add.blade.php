@extends('layouts.app')

@section('content')
    <h1>Tambah Data</h1>
    
        <form action="/zakat/create" method="POST" enctype="multipart/form-data">
                            {{csrf_field()}}
                            <!-- last time you stuck here with displaying error help-block -->
                            
                            <div class="form-group{{$errors->has('nama_pengirim') ? 'has-error' : ''}}">
                                <label for="exampleInputEmail1">Nama Lengkap</label>
                                <input name="nama_pengirim" value="{{old('nama_pengirim')}}" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Masukkan Nama Pengirim">
                                @if($errors->has('nama_pengirim'))
                                <span class="help-block">{{$errors->first('nama_pengirim')}}</span>
                              @endif
                            </div>
                            <div class="form-group{{$errors->has('nama_penerima') ? 'has-error' : ''}}">
                                    <label for="exampleInputEmail1">Nama Lengkap</label>
                                    <input name="nama_penerima" value="{{old('nama_penerima')}}" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Masukkan Nama Penerima">
                                    @if($errors->has('nama_penerima'))
                                    <span class="help-block">{{$errors->first('nama_penerima')}}</span>
                                  @endif
                            </div>
                            <div class="form-group{{$errors->has('nominal_zakat') ? 'has-error' : ''}}">
                                    <label for="exampleInputEmail1">Nama Lengkap</label>
                                    <input name="nominal_zakat" value="{{old('nominal_zakat')}}" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Masukkan Nominal Zakat">
                                    @if($errors->has('nominal_zakat'))
                                    <span class="help-block">{{$errors->first('nominal_zakat')}}</span>
                                  @endif
                            </div>
                            <div class="form-group{{$errors->has('tanggal_terima') ? 'has-error' : ''}}">
                                    <label for="exampleInputEmail1">Tanggal Terima</label>
                                    <input name="tanggal_terima" value="{{old('tanggal_terima')}}" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="yyyy-mm-dd">
                                    @if($errors->has('tanggal_terima'))
                                    <span class="help-block">{{$errors->first('tanggal_terima')}}</span>
                                  @endif
                            </div>
                            
            <button type="submit" class="btn btn-primary">Submit</button>
        
        </form>
@endsection