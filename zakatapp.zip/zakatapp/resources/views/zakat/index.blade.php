@extends('layouts.app')

@section('content')
<!--Heading-->
<div class="row">
    <div class="col-6">
        <h1>Data Zakat</h1>
    </div>
    @if(!Auth::guest())
      <div class="col-6">
        <a href="/zakat/add" class="btn btn-sm btn-primary float-right">Tambah Data</a>  
      </div>
    @endif
</div>
    <!--Table-->
    @if(count($data_zakat)>0)
        <table class="table table-hover">
                <thead>
                  <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Nama Pengirim</th>
                    <th scope="col">Nama Penerima</th>
                    <th scope="col">Nominal</th>
                    <th scope="col">Tanggal</th>
                    <th scope="col">Aksi</th>
                  </tr>
                </thead>
                <tbody>
                    @foreach($data_zakat as $zakat)
                  <tr>
                    <th scope="row">{{$zakat->id}}</th>
                    <td>{{$zakat->nama_pengirim}}</td>
                    <td>{{$zakat->nama_penerima}}</td>
                    <td>{{$zakat->nominal_zakat}}</td>
                    <td>{{$zakat->tanggal_terima}}</td>
                    <td>
                      @if(!Auth::guest())
                      <a href="/zakat/{{$zakat->id}}/edit" class="btn btn-outline-secondary btn-sm">Edit</a>
                      <a href="/zakat/{{$zakat->id}}/delete" class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin dihapus?')">Delete</a>
                      @endif
                    </td>
                  </tr>
                  @endforeach
                </tbody>
              </table>
            @else
              <p>No Data Found</p>
        @endif
@endsection