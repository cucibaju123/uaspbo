@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                    <h3>Welcome, {{auth()->user()->name}}</h3>
                    <hr>
                    <div>
                        <p>Zaco merupakan aplikasi pencatatan zakat mal untuk mempermudah
                            pencatatan zakat secara otomatis dan lebih praktis, menggunakan
                            sistem berbasis web dan dibangun dengan framework php terkini
                            agar pengguna dapat dengan nyaman menggunakan 
                            berbagai fitur Zaco dimanapun, kapanpun.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
