<?php $__env->startSection('content'); ?>
    <h1>Tambah Data</h1>
    
        <form action="/zakat/create" method="POST" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            <!-- last time you stuck here with displaying error help-block -->
                            
                            <div class="form-group<?php echo e($errors->has('nama_pengirim') ? 'has-error' : ''); ?>">
                                <label for="exampleInputEmail1">Nama Lengkap</label>
                                <input name="nama_pengirim" value="<?php echo e(old('nama_pengirim')); ?>" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Masukkan Nama Pengirim">
                                <?php if($errors->has('nama_pengirim')): ?>
                                <span class="help-block"><?php echo e($errors->first('nama_pengirim')); ?></span>
                              <?php endif; ?>
                            </div>
                            <div class="form-group<?php echo e($errors->has('nama_penerima') ? 'has-error' : ''); ?>">
                                    <label for="exampleInputEmail1">Nama Lengkap</label>
                                    <input name="nama_penerima" value="<?php echo e(old('nama_penerima')); ?>" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Masukkan Nama Penerima">
                                    <?php if($errors->has('nama_penerima')): ?>
                                    <span class="help-block"><?php echo e($errors->first('nama_penerima')); ?></span>
                                  <?php endif; ?>
                            </div>
                            <div class="form-group<?php echo e($errors->has('nominal_zakat') ? 'has-error' : ''); ?>">
                                    <label for="exampleInputEmail1">Nama Lengkap</label>
                                    <input name="nominal_zakat" value="<?php echo e(old('nominal_zakat')); ?>" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Masukkan Nominal Zakat">
                                    <?php if($errors->has('nominal_zakat')): ?>
                                    <span class="help-block"><?php echo e($errors->first('nominal_zakat')); ?></span>
                                  <?php endif; ?>
                            </div>
                            <div class="form-group<?php echo e($errors->has('tanggal_terima') ? 'has-error' : ''); ?>">
                                    <label for="exampleInputEmail1">Tanggal Terima</label>
                                    <input name="tanggal_terima" value="<?php echo e(old('tanggal_terima')); ?>" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="yyyy-mm-dd">
                                    <?php if($errors->has('tanggal_terima')): ?>
                                    <span class="help-block"><?php echo e($errors->first('tanggal_terima')); ?></span>
                                  <?php endif; ?>
                            </div>
                            
            <button type="submit" class="btn btn-primary">Submit</button>
        
        </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\zakatapp\resources\views/zakat/add.blade.php ENDPATH**/ ?>