<?php $__env->startSection('content'); ?>
<!--Heading-->
<div class="row">
    <div class="col-6">
        <h1>Data Zakat</h1>
    </div>
    <?php if(!Auth::guest()): ?>
      <div class="col-6">
        <a href="/zakat/add" class="btn btn-sm btn-primary float-right">Tambah Data</a>  
      </div>
    <?php endif; ?>
</div>
    <!--Table-->
    <?php if(count($data_zakat)>0): ?>
        <table class="table table-hover">
                <thead>
                  <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Nama Pengirim</th>
                    <th scope="col">Nama Penerima</th>
                    <th scope="col">Nominal</th>
                    <th scope="col">Tanggal</th>
                    <th scope="col">Aksi</th>
                  </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data_zakat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zakat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <th scope="row"><?php echo e($zakat->id); ?></th>
                    <td><?php echo e($zakat->nama_pengirim); ?></td>
                    <td><?php echo e($zakat->nama_penerima); ?></td>
                    <td><?php echo e($zakat->nominal_zakat); ?></td>
                    <td><?php echo e($zakat->tanggal_terima); ?></td>
                    <td>
                      <?php if(!Auth::guest()): ?>
                      <a href="/zakat/<?php echo e($zakat->id); ?>/edit" class="btn btn-outline-secondary btn-sm">Edit</a>
                      <a href="/zakat/<?php echo e($zakat->id); ?>/delete" class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin dihapus?')">Delete</a>
                      <?php endif; ?>
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            <?php else: ?>
              <p>No Data Found</p>
        <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\zakatapp\resources\views/zakat/index.blade.php ENDPATH**/ ?>